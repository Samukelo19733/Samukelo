import os
import sys
import json
import re
import subprocess
import platform
import uuid
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QTextEdit, QAction, QFileDialog,
    QVBoxLayout, QWidget, QMessageBox, QComboBox, QDialog,
    QFormLayout, QPushButton, QPlainTextEdit, QHBoxLayout,
    QLineEdit, QTreeWidget, QTreeWidgetItem, QListWidget,
    QGridLayout, QCheckBox, QLabel, QFontComboBox, QSpinBox,
    QColorDialog, QInputDialog, QGroupBox, QRadioButton,
    QTabWidget, QScrollArea
)
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QFont, QTextCharFormat, QSyntaxHighlighter, QColor

class ColorScheme:
    SCHEMES = {
        "Light": {
            "background": "#FFFFFF",
            "foreground": "#000000",
            "keyword": "#0000FF",
            "comment": "#008000",
            "string": "#A31515",
            "line_numbers_bg": "#F0F0F0",
            "line_numbers_fg": "#000000"
        },
        "Dark": {
            "background": "#1E1E1E",
            "foreground": "#D4D4D4",
            "keyword": "#569CD6",
            "comment": "#6A9955",
            "string": "#CE917F",
            "line_numbers_bg": "#2D2D2D",
            "line_numbers_fg": "#D4D4D4"
        },
        "Solarized Light": {
            "background": "#FDF6E3",
            "foreground": "#657B83",
            "keyword": "#268BD2",
            "comment": "#93A1A1",
            "string": "#2AA198",
            "line_numbers_bg": "#EEE8D5",
            "line_numbers_fg": "#657B83"
        },
        "Solarized Dark": {
            "background": "#002B36",
            "foreground": "#839496",
            "keyword": "#268BD2",
            "comment": "#586E75",
            "string": "#2AA198",
            "line_numbers_bg": "#073642",
            "line_numbers_fg": "#839496"
        },
        "Monokai": {
            "background": "#272822",
            "foreground": "#F8F8F2",
            "keyword": "#F92672",
            "comment": "#75715E",
            "string": "#E6DB74",
            "line_numbers_bg": "#3E3D32",
            "line_numbers_fg": "#F8F8F2"
        },
        "Dracula": {
            "background": "#282A36",
            "foreground": "#F8F8F2",
            "keyword": "#FF79C6",
            "comment": "#6272A4",
            "string": "#F1FA8C",
            "line_numbers_bg": "#44475A",
            "line_numbers_fg": "#F8F8F2"
        },
        "One Dark": {
            "background": "#282C34",
            "foreground": "#ABB2BF",
            "keyword": "#61AFEF",
            "comment": "#5C6370",
            "string": "#98C379",
            "line_numbers_bg": "#21252B",
            "line_numbers_fg": "#ABB2BF"
        },
        "Nord": {
            "background": "#2E3440",
            "foreground": "#D8DEE9",
            "keyword": "#81A1C1",
            "comment": "#4C566A",
            "string": "#A3BE8C",
            "line_numbers_bg": "#3B4252",
            "line_numbers_fg": "#D8DEE9"
        },
        "Gruvbox": {
            "background": "#282828",
            "foreground": "#EBDBB2",
            "keyword": "#FB4934",
            "comment": "#928374",
            "string": "#B8BB26",
            "line_numbers_bg": "#3C3836",
            "line_numbers_fg": "#EBDBB2"
        },
        "Tomorrow Light": {
            "background": "#FFFFFF",
            "foreground": "#4D4D4C",
            "keyword": "#8959A8",
            "comment": "#8E908C",
            "string": "#718C00",
            "line_numbers_bg": "#EFEFEF",
            "line_numbers_fg": "#4D4D4C"
        }
    }

    def __init__(self, name="Light", custom_colors=None):
        self.name = name
        self.colors = custom_colors or self.SCHEMES.get(name, self.SCHEMES["Light"])

    def get_color(self, key):
        return QColor(self.colors[key])

class ColorSchemeDialog(QDialog):
    def __init__(self, parent=None, current_scheme=None):
        super().__init__(parent)
        self.setWindowTitle("Customize Color Scheme")
        self.scheme = current_scheme or ColorScheme()
        self.setup_ui()

    def setup_ui(self):
        layout = QFormLayout()
        self.color_buttons = {}
        for key, value in self.scheme.colors.items():
            button = QPushButton()
            button.setStyleSheet(f"background-color: {value}; min-height: 30px;")
            button.clicked.connect(lambda checked, k=key: self.select_color(k))
            self.color_buttons[key] = button
            layout.addRow(f"{key.replace('_', ' ').title()}:", button)
        apply_button = QPushButton("Apply")
        apply_button.clicked.connect(self.accept)
        layout.addWidget(apply_button)
        self.setLayout(layout)

    def select_color(self, key):
        current_color = QColor(self.scheme.colors[key])
        color = QColorDialog.getColor(current_color, self, f"Select {key.replace('_', ' ').title()} Color")
        if color.isValid():
            self.update_color(key, color)

    def update_color(self, key, color):
        hex_color = color.name().upper()
        self.scheme.colors[key] = hex_color
        self.color_buttons[key].setStyleSheet(f"background-color: {hex_color}; min-height: 30px;")

    def get_scheme(self):
        return ColorScheme("Custom", self.scheme.colors.copy())

class FontDialog(QDialog):
    def __init__(self, parent=None, current_font=None, current_size=10):
        super().__init__(parent)
        self.setWindowTitle("Select Font")
        self.current_font = current_font or QFont("Courier New")
        self.current_size = current_size
        layout = QFormLayout()
        self.font_combo = QFontComboBox()
        self.font_combo.setFontFilters(QFontComboBox.MonospacedFonts)
        self.font_combo.setCurrentFont(self.current_font)
        layout.addRow("Font:", self.font_combo)
        self.size_combo = QComboBox()
        self.size_combo.addItems(["8", "10", "12", "14", "16"])
        self.size_combo.setCurrentText(str(self.current_size))
        layout.addRow("Size (pt):", self.size_combo)
        apply_button = QPushButton("Apply")
        apply_button.clicked.connect(self.accept)
        layout.addWidget(apply_button)
        self.setLayout(layout)

    def get_font(self):
        return self.font_combo.currentFont()

    def get_size(self):
        return int(self.size_combo.currentText())

class ToolConfigDialog(QDialog):
    def __init__(self, parent=None, current_tools=None):
        super().__init__(parent)
        self.setWindowTitle("Configure Tools")
        self.tools = current_tools or {"xc8": "", "avr-gcc": ""}
        self.executables = {
            "xc8": "xc8-cc",
            "avr-gcc": "avr-gcc"
        }
        self.setup_ui()
        self.search_tool_paths()
        self.update_status_indicators()

    def setup_ui(self):
        layout = QFormLayout()
        
        # XC8 Path
        self.xc8_path = QLineEdit(self.tools["xc8"])
        self.xc8_path.setReadOnly(True)
        self.xc8_browse = QPushButton("Browse")
        self.xc8_browse.clicked.connect(lambda: self.browse_path("xc8"))
        self.xc8_status = QLabel("")
        xc8_layout = QHBoxLayout()
        xc8_layout.addWidget(self.xc8_path)
        xc8_layout.addWidget(self.xc8_browse)
        layout.addRow("XC8 Path:", xc8_layout)
        layout.addRow("", self.xc8_status)
        
        # AVR-GCC Path
        self.avr_gcc_path = QLineEdit(self.tools["avr-gcc"])
        self.avr_gcc_path.setReadOnly(True)
        self.avr_gcc_browse = QPushButton("Browse")
        self.avr_gcc_browse.clicked.connect(lambda: self.browse_path("avr-gcc"))
        self.avr_gcc_status = QLabel("")
        avr_gcc_layout = QHBoxLayout()
        avr_gcc_layout.addWidget(self.avr_gcc_path)
        avr_gcc_layout.addWidget(self.avr_gcc_browse)
        layout.addRow("AVR-GCC Path:", avr_gcc_layout)
        layout.addRow("", self.avr_gcc_status)
        
        save_button = QPushButton("Save")
        save_button.clicked.connect(self.validate_and_save)
        layout.addWidget(save_button)
        self.setLayout(layout)

    def browse_path(self, tool):
        path = QFileDialog.getExistingDirectory(
            self,
            f"Select {tool} Directory",
            os.path.expanduser("~")
        )
        if path:
            executable = self.executables[tool]
            if os.path.isfile(os.path.join(path, executable)) or os.path.isfile(os.path.join(path, "bin", executable)):
                self.tools[tool] = path
                if tool == "xc8":
                    self.xc8_path.setText(path)
                elif tool == "avr-gcc":
                    self.avr_gcc_path.setText(path)
                self.update_status_indicators()
            else:
                QMessageBox.warning(self, "Invalid Directory", f"No {executable} found in the selected directory.")

    def search_tool_paths(self):
        search_paths = []
        if platform.system() == "Windows":
            search_paths = [
                "C:\\Program Files",
                "C:\\Program Files (x86)",
                "C:\\Microchip\\xc8",
                "C:\\avr-gcc"
            ]
        else:
            search_paths = [
                "/usr/bin",
                "/usr/local/bin",
                "/opt",
                "/opt/microchip/xc8",
                "/opt/avr-gcc"
            ]
        for tool, executable in self.executables.items():
            for path in search_paths:
                if not os.path.exists(path):
                    continue
                for root, _, files in os.walk(path):
                    if executable in files or os.path.exists(os.path.join(root, "bin", executable)):
                        self.tools[tool] = root
                        break
                if self.tools[tool]:
                    break
        self.xc8_path.setText(self.tools["xc8"])
        self.avr_gcc_path.setText(self.tools["avr-gcc"])

    def update_status_indicators(self):
        tools = {
            "xc8": self.xc8_path.text(),
            "avr-gcc": self.avr_gcc_path.text()
        }
        status_labels = {
            "xc8": self.xc8_status,
            "avr-gcc": self.avr_gcc_status
        }
        for tool, path in tools.items():
            valid = path and (
                os.path.isfile(os.path.join(path, self.executables[tool])) or
                os.path.isfile(os.path.join(path, "bin", self.executables[tool]))
            )
            status_labels[tool].setText(
                "<font color='green'>✓</font>" if valid else "<font color='red'>✗</font>"
            )

    def validate_and_save(self):
        tools = {
            "xc8": self.xc8_path.text(),
            "avr-gcc": self.avr_gcc_path.text()
        }
        for tool, path in tools.items():
            if path:
                executable = self.executables[tool]
                if not (
                    os.path.isfile(os.path.join(path, executable)) or
                    os.path.isfile(os.path.join(path, "bin", executable))
                ):
                    QMessageBox.warning(self, "Invalid Path", f"Invalid {tool} path.")
                    return
        self.tools = tools
        self.accept()

    def get_tools(self):
        return self.tools

class MicrocontrollerDialog(QDialog):
    MICROCONTROLLERS = {
        "PIC10": [
            "PIC10F200", "PIC10F202", "PIC10F204", "PIC10F206", "PIC10F220", "PIC10F222",
            "PIC10F320", "PIC10F322"
        ],
        "PIC12": [
            "PIC12F508", "PIC12F509", "PIC12F510", "PIC12F519", "PIC12F609", "PIC12F615",
            "PIC12F629", "PIC12F675", "PIC12F683", "PIC12F752", "PIC12F1501", "PIC12F1571",
            "PIC12F1572", "PIC12F1822", "PIC12F1840"
        ],
        "PIC16": [
            "PIC16F505", "PIC16F506", "PIC16F526", "PIC16F610", "PIC16F616", "PIC16F627",
            "PIC16F627A", "PIC16F628", "PIC16F628A", "PIC16F630", "PIC16F636", "PIC16F639",
            "PIC16F648A", "PIC16F676", "PIC16F677", "PIC16F684", "PIC16F685", "PIC16F687",
            "PIC16F688", "PIC16F689", "PIC16F690", "PIC16F716", "PIC16F722", "PIC16F723",
            "PIC16F724", "PIC16F726", "PIC16F727", "PIC16F737", "PIC16F747", "PIC16F767",
            "PIC16F777", "PIC16F785", "PIC16F818", "PIC16F819", "PIC16F84A", "PIC16F870",
            "PIC16F871", "PIC16F872", "PIC16F873A", "PIC16F874A", "PIC16F876A", "PIC16F877A",
            "PIC16F882", "PIC16F883", "PIC16F884", "PIC16F886", "PIC16F887", "PIC16F913",
            "PIC16F914", "PIC16F916", "PIC16F917", "PIC16F946", "PIC16F1454", "PIC16F1455",
            "PIC16F1459", "PIC16F1503", "PIC16F1507", "PIC16F1508", "PIC16F1509", "PIC16F1516",
            "PIC16F1517", "PIC16F1518", "PIC16F1519", "PIC16F1526", "PIC16F1527", "PIC16F1574",
            "PIC16F1575", "PIC16F1578", "PIC16F1579", "PIC16F1703", "PIC16F1704", "PIC16F1705",
            "PIC16F1707", "PIC16F1708", "PIC16F1709", "PIC16F1713", "PIC16F1716", "PIC16F1717",
            "PIC16F1718", "PIC16F1719", "PIC16F1782", "PIC16F1783", "PIC16F1784", "PIC16F1786",
            "PIC16F1787", "PIC16F1788", "PIC16F1789", "PIC16F1823", "PIC16F1824", "PIC16F1825",
            "PIC16F1826", "PIC16F1827", "PIC16F1828", "PIC16F1829", "PIC16F18313", "PIC16F18323",
            "PIC16F18324", "PIC16F18325", "PIC16F18326", "PIC16F18344", "PIC16F18345", "PIC16F18346",
            "PIC16F18855", "PIC16F18875", "PIC16F18877"
        ],
        "PIC18": [
            "PIC18F1220", "PIC18F1320", "PIC18F2220", "PIC18F2221", "PIC18F2320", "PIC18F2321",
            "PIC18F2410", "PIC18F2420", "PIC18F2423", "PIC18F2431", "PIC18F2450", "PIC18F2455",
            "PIC18F2458", "PIC18F2480", "PIC18F2510", "PIC18F2515", "PIC18F2520", "PIC18F2523",
            "PIC18F2525", "PIC18F2550", "PIC18F2553", "PIC18F2580", "PIC18F2585", "PIC18F2610",
            "PIC18F2620", "PIC18F2680", "PIC18F2682", "PIC18F2685", "PIC18F4220", "PIC18F4221",
            "PIC18F4320", "PIC18F4321", "PIC18F4410", "PIC18F4420", "PIC18F4423", "PIC18F4431",
            "PIC18F4450", "PIC18F4455", "PIC18F4458", "PIC18F4480", "PIC18F4510", "PIC18F4515",
            "PIC18F4520", "PIC18F4523", "PIC18F4525", "PIC18F4550", "PIC18F4553", "PIC18F4580",
            "PIC18F4585", "PIC18F4610", "PIC18F4620", "PIC18F4680", "PIC18F4682", "PIC18F4685",
            "PIC18F6520", "PIC18F6527", "PIC18F6585", "PIC18F6620", "PIC18F6622", "PIC18F6627",
            "PIC18F6680", "PIC18F6720", "PIC18F6722", "PIC18F8520", "PIC18F8527", "PIC18F8585",
            "PIC18F8620", "PIC18F8622", "PIC18F8627", "PIC18F8680", "PIC18F8720", "PIC18F8722"
        ],
        "ATMega": [
            "ATMega8", "ATMega16", "ATMega32", "ATMega48", "ATMega48P", "ATMega88",
            "ATMega88P", "ATMega128", "ATMega164P", "ATMega168", "ATMega168P",
            "ATMega324P", "ATMega328", "ATMega328P", "ATMega644", "ATMega644P",
            "ATMega1284P", "ATMega2560"
        ],
        "ATtiny": [
            "ATtiny13", "ATtiny13A", "ATtiny24", "ATtiny24A", "ATtiny25", "ATtiny44",
            "ATtiny44A", "ATtiny45", "ATtiny84", "ATtiny84A", "ATtiny85", "ATtiny2313",
            "ATtiny4313"
        ]
    }

    def __init__(self, parent=None, current_device=None):
        super().__init__(parent)
        self.setWindowTitle("Select Microcontroller")
        self.selected_device = current_device or "PIC16F877A"
        layout = QGridLayout()
        self.search_input = QLineEdit()
        self.search_input.textChanged.connect(self.filter_devices)
        layout.addWidget(self.search_input, 0, 0, 1, 2)
        self.device_tree = QTreeWidget()
        self.device_tree.setHeaderLabel("Microcontrollers")
        self.populate_tree()
        self.device_tree.itemClicked.connect(self.on_tree_item_clicked)
        layout.addWidget(self.device_tree, 1, 0)
        self.device_list = QListWidget()
        self.device_list.itemClicked.connect(self.on_list_item_clicked)
        self.populate_list("")
        layout.addWidget(self.device_list, 1, 1)
        select_button = QPushButton("Select")
        select_button.clicked.connect(self.accept)
        layout.addWidget(select_button, 2, 0, 1, 2)
        self.setLayout(layout)

    def populate_tree(self):
        for family, devices in self.MICROCONTROLLERS.items():
            family_item = QTreeWidgetItem(self.device_tree, [family])
            for device in devices:
                QTreeWidgetItem(family_item, [device])

    def populate_list(self, filter_text):
        self.device_list.clear()
        for family, devices in self.MICROCONTROLLERS.items():
            for device in devices:
                if filter_text.lower() in device.lower():
                    self.device_list.addItem(device)

    def filter_devices(self, text):
        self.populate_list(text)
        if self.device_list.count() > 0:
            self.selected_device = self.device_list.item(0).text()

    def on_tree_item_clicked(self, item):
        if item.parent():
            self.selected_device = item.text(0)
            self.device_list.clear()
            self.device_list.addItem(self.selected_device)

    def on_list_item_clicked(self, item):
        self.selected_device = item.text()

    def get_selected_device(self):
        return self.selected_device

class ChipConfigDialog(QDialog):
    PIC_CONFIG_BITS = {
        "PIC16F877A": {
            "CONFIG1": {
                "bits": [
                    ("FOSC0", "Oscillator Selection bit 0"),
                    ("FOSC1", "Oscillator Selection bit 1"),
                    ("FOSC2", "Oscillator Selection bit 2"),
                    ("WDTE", "Watchdog Timer Enable bit"),
                    ("PWRTE", "Power-up Timer Enable bit"),
                    ("CP", "Flash Program Memory Code Protection bit"),
                    ("BOREN", "Brown-out Reset Enable bit"),
                    ("LVP", "Low-Voltage Programming Enable bit"),
                    ("CPD", "Data EEPROM Code Protection bit"),
                    ("WRT", "Flash Program Memory Write Enable bits"),
                    ("DEBUG", "Debug Enable bit"),
                    ("RESERVED", "Reserved bits")
                ],
                "osc_options": {
                    "LP": "Low-power crystal on RA6/RA7",
                    "XT": "Crystal/resonator on RA6/RA7",
                    "HS": "High-speed crystal/resonator on RA6/RA7",
                    "RC": "External RC on RA6/OSC2, CLKOUT on RA7/OSC1",
                    "EC": "External clock on RA6/OSC2, CLKOUT on RA7/OSC1",
                    "INTRC": "Internal oscillator, CLKOUT on RA6/OSC2, I/O on RA7/OSC1",
                    "INTRCIO": "Internal oscillator, I/O on RA6/OSC2, I/O on RA7/OSC1",
                    "EXTRC": "External RC on RA6/OSC2, I/O on RA7/OSC1",
                    "EXTRCIO": "External RC on RA6/OSC2, I/O on RA7/OSC1",
                    "INTOSCIO": "Internal oscillator, I/O on RA6/OSC2, I/O on RA7/OSC1",
                    "INTOSC": "Internal oscillator, CLKOUT on RA6/OSC2, I/O on RA7/OSC1"
                }
            },
            "CONFIG2": {
                "bits": [
                    ("BORV0", "Brown-out Reset Voltage Selection bit 0"),
                    ("BORV1", "Brown-out Reset Voltage Selection bit 1"),
                    ("WRT0", "Flash Program Memory Write Enable bit 0"),
                    ("WRT1", "Flash Program Memory Write Enable bit 1"),
                    ("WRT2", "Flash Program Memory Write Enable bit 2"),
                    ("WRT3", "Flash Program Memory Write Enable bit 3"),
                    ("WDTPS0", "Watchdog Timer Postscale Select bit 0"),
                    ("WDTPS1", "Watchdog Timer Postscale Select bit 1"),
                    ("WDTPS2", "Watchdog Timer Postscale Select bit 2"),
                    ("WDTPS3", "Watchdog Timer Postscale Select bit 3"),
                    ("WDTPS4", "Watchdog Timer Postscale Select bit 4")
                ]
            }
        },
        "PIC18F4550": {
            "CONFIG1L": {
                "bits": [
                    ("PLLDIV0", "PLL Prescaler Selection bits 0"),
                    ("PLLDIV1", "PLL Prescaler Selection bits 1"),
                    ("PLLDIV2", "PLL Prescaler Selection bits 2"),
                    ("CPUDIV0", "System Clock Postscaler Selection bits 0"),
                    ("CPUDIV1", "System Clock Postscaler Selection bits 1"),
                    ("USBDIV", "USB Clock Selection bit")
                ]
            },
            "CONFIG1H": {
                "bits": [
                    ("FOSC0", "Oscillator Selection bits 0"),
                    ("FOSC1", "Oscillator Selection bits 1"),
                    ("FOSC2", "Oscillator Selection bits 2"),
                    ("FOSC3", "Oscillator Selection bits 3"),
                    ("FCMEN", "Fail-Safe Clock Monitor Enable bit"),
                    ("IESO", "Internal/External Oscillator Switchover bit")
                ],
                "osc_options": {
                    "LP": "Low-power crystal",
                    "XT": "Crystal/resonator",
                    "HS": "High-speed crystal/resonator",
                    "RC": "External RC oscillator, CLKO on RA6",
                    "EC": "External clock, CLKO on RA6",
                    "ECIO": "External clock, I/O on RA6",
                    "HSPLL": "HS oscillator with PLL enabled",
                    "RCIO": "External RC oscillator, I/O on RA6",
                    "INTIO1": "Internal oscillator, port function on RA6 and RA7",
                    "INTIO2": "Internal oscillator, port function on RA6, CLKO on RA7",
                    "INTOSC": "Internal oscillator, CLKO on RA6, port function on RA7",
                    "INTOSCIO": "Internal oscillator, port function on RA6 and RA7",
                    "RC": "External RC oscillator, CLKO on RA6",
                    "EC": "External clock, CLKO on RA6"
                }
            },
            "CONFIG2L": {
                "bits": [
                    ("PWRTEN", "Power-up Timer Enable bit"),
                    ("BOREN0", "Brown-out Reset Enable bits 0"),
                    ("BOREN1", "Brown-out Reset Enable bits 1"),
                    ("BORV0", "Brown-out Reset Voltage bits 0"),
                    ("BORV1", "Brown-out Reset Voltage bits 1"),
                    ("BORV2", "Brown-out Reset Voltage bits 2"),
                    ("VREGEN", "USB Voltage Regulator Enable bit")
                ]
            },
            "CONFIG2H": {
                "bits": [
                    ("WDTEN", "Watchdog Timer Enable bit"),
                    ("WDTPS0", "Watchdog Timer Postscale Select bits 0"),
                    ("WDTPS1", "Watchdog Timer Postscale Select bits 1"),
                    ("WDTPS2", "Watchdog Timer Postscale Select bits 2"),
                    ("WDTPS3", "Watchdog Timer Postscale Select bits 3"),
                    ("WDTPS4", "Watchdog Timer Postscale Select bits 4")
                ]
            },
            "CONFIG3H": {
                "bits": [
                    ("PBADEN", "PORTB A/D Enable bit"),
                    ("LPT1OSC", "Low-Power Timer1 Oscillator Enable bit"),
                    ("MCLRE", "MCLR Pin Enable bit"),
                    ("CCP2MX", "CCP2 MUX bit")
                ]
            },
            "CONFIG4L": {
                "bits": [
                    ("STVREN", "Stack Full/Underflow Reset Enable bit"),
                    ("LVP", "Single-Supply ICSP Enable bit"),
                    ("XINST", "Extended Instruction Set Enable bit"),
                    ("DEBUG", "Background Debugger Enable bit")
                ]
            },
            "CONFIG5L": {
                "bits": [
                    ("CP0", "Code Protection bit 0"),
                    ("CP1", "Code Protection bit 1"),
                    ("CP2", "Code Protection bit 2"),
                    ("CP3", "Code Protection bit 3")
                ]
            },
            "CONFIG5H": {
                "bits": [
                    ("CPB", "Boot Block Code Protection bit"),
                    ("CPD", "Data EEPROM Code Protection bit")
                ]
            },
            "CONFIG6L": {
                "bits": [
                    ("WRT0", "Write Protection bit 0"),
                    ("WRT1", "Write Protection bit 1"),
                    ("WRT2", "Write Protection bit 2"),
                    ("WRT3", "Write Protection bit 3")
                ]
            },
            "CONFIG6H": {
                "bits": [
                    ("WRTC", "Configuration Register Write Protection bit"),
                    ("WRTB", "Boot Block Write Protection bit"),
                    ("WRTD", "Data EEPROM Write Protection bit")
                ]
            },
            "CONFIG7L": {
                "bits": [
                    ("EBTR0", "Table Read Protection bit 0"),
                    ("EBTR1", "Table Read Protection bit 1"),
                    ("EBTR2", "Table Read Protection bit 2"),
                    ("EBTR3", "Table Read Protection bit 3")
                ]
            },
            "CONFIG7H": {
                "bits": [
                    ("EBTRB", "Boot Block Table Read Protection bit")
                ]
            }
        }
    }

    AVR_CONFIG_BITS = {
        "ATMega328P": {
            "FUSE_LOW": {
                "bits": [
                    ("CKSEL0", "Select Clock Source bit 0"),
                    ("CKSEL1", "Select Clock Source bit 1"),
                    ("CKSEL2", "Select Clock Source bit 2"),
                    ("CKSEL3", "Select Clock Source bit 3"),
                    ("SUT0", "Start-up Time bit 0"),
                    ("SUT1", "Start-up Time bit 1"),
                    ("CKOUT", "Clock Output Enable bit"),
                    ("CKDIV8", "Divide Clock by 8 Enable bit")
                ],
                "osc_options": {
                    "EXTCLK": "External Clock",
                    "RC": "Internal RC Oscillator",
                    "LF": "Low-frequency Crystal",
                    "XT": "Full Swing Crystal",
                    "HS": "High-speed Crystal"
                }
            },
            "FUSE_HIGH": {
                "bits": [
                    ("BOOTRST", "Boot Reset Vector Enable bit"),
                    ("BOOTSZ0", "Boot Size Select bit 0"),
                    ("BOOTSZ1", "Boot Size Select bit 1"),
                    ("EESAVE", "EEPROM Save During Sleep bit"),
                    ("WDTON", "Watchdog Timer Always On bit"),
                    ("SPIEN", "Serial Program Downloading Enable bit"),
                    ("DWEN", "Debug Wire Enable bit"),
                    ("RSTDISBL", "Reset Disable bit")
                ]
            },
            "FUSE_EXTENDED": {
                "bits": [
                    ("BODLEVEL0", "Brown-out Detector Trigger Level bit 0"),
                    ("BODLEVEL1", "Brown-out Detector Trigger Level bit 1"),
                    ("BODLEVEL2", "Brown-out Detector Trigger Level bit 2")
                ]
            }
        }
    }

    def __init__(self, parent=None, device="PIC16F877A"):
        super().__init__(parent)
        self.setWindowTitle("Configure Chip")
        self.device = device
        self.osc_type = "INTOSCIO"
        self.frequency = "4"
        self.config_values = {}
        self.setup_ui()

    def setup_ui(self):
        self.setMinimumSize(800, 600)
        layout = QVBoxLayout()
        
        # Device info
        device_label = QLabel(f"Configuring: {self.device}")
        device_label.setStyleSheet("font-weight: bold; font-size: 14px;")
        layout.addWidget(device_label)
        
        # Oscillator and frequency selection
        osc_group = QGroupBox("Oscillator Configuration")
        osc_layout = QFormLayout()
        
        # Remove prefix from device name
        chip_name = self.device
        if chip_name.startswith("PIC"):
            chip_name = chip_name[3:]
        elif chip_name.startswith("AT"):
            chip_name = chip_name[2:]
        
        self.chip_line = QLineEdit(f"#CHIP {chip_name},")
        self.chip_line.setReadOnly(True)
        osc_layout.addRow("Chip Definition:", self.chip_line)
        
        # Oscillator type selection
        self.osc_combo = QComboBox()
        config_data = self.get_config_data()
        if "osc_options" in config_data:
            for osc_type, desc in config_data["osc_options"].items():
                self.osc_combo.addItem(f"{osc_type} - {desc}", osc_type)
        else:
            self.osc_combo.addItems(["INTOSCIO", "XT", "HS", "LP", "EC", "RC"])
        self.osc_combo.setCurrentText(self.osc_type)
        self.osc_combo.currentTextChanged.connect(self.update_chip_line)
        osc_layout.addRow("Oscillator Type:", self.osc_combo)
        
        # Frequency selection
        self.freq_combo = QComboBox()
        if "PIC18F" in self.device:
            self.freq_combo.addItems(["1", "4", "8", "12", "16", "20", "24", "32", "40", "48"])
        else:
            self.freq_combo.addItems(["1", "4", "8", "16", "20"])
        self.freq_combo.setCurrentText(self.frequency)
        self.freq_combo.currentTextChanged.connect(self.update_chip_line)
        osc_layout.addRow("Frequency (MHz):", self.freq_combo)
        
        osc_group.setLayout(osc_layout)
        layout.addWidget(osc_group)
        
        # Configuration bits
        config_group = QGroupBox("Configuration Bits")
        config_layout = QHBoxLayout()
        
        # Create tabs for different config words
        self.tabs = QTabWidget()
        
        # Get config data for this device
        config_data = self.get_config_data()
        
        for config_word, config_info in config_data.items():
            tab = QWidget()
            tab_layout = QFormLayout()
            
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll_content = QWidget()
            scroll_layout = QFormLayout(scroll_content)
            
            for bit_name, bit_desc in config_info.get("bits", []):
                if bit_name == "RESERVED":
                    continue
                    
                bit_group = QGroupBox(bit_name)
                bit_group.setToolTip(bit_desc)
                bit_layout = QVBoxLayout()
                
                # Add radio buttons for each possible value
                if bit_name.startswith(("FOSC", "CKSEL", "BOR")):
                    # For multi-bit fields, add a combo box
                    combo = QComboBox()
                    if bit_name.startswith("FOSC"):
                        combo.addItems(["00", "01", "10", "11"])
                    elif bit_name.startswith("BOR"):
                        combo.addItems(["00", "01", "10", "11"])
                    elif bit_name.startswith("CKSEL"):
                        combo.addItems(["0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111",
                                      "1000", "1001", "1010", "1011", "1100", "1101", "1110", "1111"])
                    combo.currentTextChanged.connect(self.update_config_hex)
                    bit_layout.addWidget(combo)
                    bit_layout.addWidget(QLabel(bit_desc))
                    
                    # Store combo reference
                    if config_word not in self.config_values:
                        self.config_values[config_word] = {}
                    self.config_values[config_word][bit_name] = combo
                else:
                    # For single bits, add checkboxes
                    checkbox = QCheckBox("Enabled")
                    checkbox.setToolTip(bit_desc)
                    checkbox.stateChanged.connect(self.update_config_hex)
                    bit_layout.addWidget(checkbox)
                    bit_layout.addWidget(QLabel(bit_desc))
                    
                    # Store checkbox reference
                    if config_word not in self.config_values:
                        self.config_values[config_word] = {}
                    self.config_values[config_word][bit_name] = checkbox
                
                bit_group.setLayout(bit_layout)
                scroll_layout.addRow(bit_group)
            
            scroll.setWidget(scroll_content)
            tab_layout.addWidget(scroll)
            tab.setLayout(tab_layout)
            self.tabs.addTab(tab, config_word)
        
        config_layout.addWidget(self.tabs)
        
        # Hex display
        hex_group = QGroupBox("Hex Values")
        hex_layout = QVBoxLayout()
        self.hex_display = QTextEdit()
        self.hex_display.setReadOnly(True)
        self.hex_display.setMaximumHeight(150)
        self.hex_display.setStyleSheet("font-family: monospace;")
        hex_layout.addWidget(self.hex_display)
        
        # Add copy button
        copy_button = QPushButton("Copy to Clipboard")
        copy_button.clicked.connect(self.copy_to_clipboard)
        hex_layout.addWidget(copy_button)
        
        hex_group.setLayout(hex_layout)
        config_layout.addWidget(hex_group)
        
        config_group.setLayout(config_layout)
        layout.addWidget(config_group)
        
        # Buttons
        button_layout = QHBoxLayout()
        insert_button = QPushButton("Insert Configuration")
        insert_button.clicked.connect(self.accept)
        button_layout.addWidget(insert_button)
        
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(cancel_button)
        
        layout.addLayout(button_layout)
        self.setLayout(layout)
        
        # Initial update
        self.update_chip_line()
        self.update_config_hex()

    def get_config_data(self):
        if self.device.startswith("PIC"):
            return self.PIC_CONFIG_BITS.get(self.device, self.PIC_CONFIG_BITS["PIC16F877A"])
        else:
            return self.AVR_CONFIG_BITS.get(self.device, self.AVR_CONFIG_BITS["ATMega328P"])

    def update_chip_line(self):
        self.osc_type = self.osc_combo.currentText().split(" - ")[0] if " - " in self.osc_combo.currentText() else self.osc_combo.currentText()
        self.frequency = self.freq_combo.currentText()
        chip_name = self.device
        if chip_name.startswith("PIC"):
            chip_name = chip_name[3:]
        elif chip_name.startswith("AT"):
            chip_name = chip_name[2:]
        self.chip_line.setText(f"#CHIP {chip_name}, {self.osc_type}, {self.frequency}")

    def update_config_hex(self):
        hex_output = []
        config_data = self.get_config_data()
        
        for config_word, config_info in config_data.items():
            value = 0
            bit_pos = 0
            
            for bit_name, bit_desc in config_info.get("bits", []):
                if bit_name == "RESERVED":
                    continue
                    
                control = self.config_values[config_word].get(bit_name)
                if isinstance(control, QCheckBox):
                    if control.isChecked():
                        value |= (1 << bit_pos)
                    bit_pos += 1
                elif isinstance(control, QComboBox):
                    # For multi-bit fields
                    bits = control.currentText()
                    if bits:
                        val = int(bits, 2)
                        value |= (val << bit_pos)
                        bit_pos += len(bits)
            
            hex_output.append(f"{config_word} = 0x{value:04X}")
        
        self.hex_display.setText("\n".join(hex_output))

    def copy_to_clipboard(self):
        clipboard = QApplication.clipboard()
        clipboard.setText(self.hex_display.toPlainText())
        QMessageBox.information(self, "Copied", "Configuration values copied to clipboard!")

    def get_config_code(self):
        chip_line = self.chip_line.text()
        hex_values = self.hex_display.toPlainText().split("\n")
        
        code = f"{chip_line}\n"
        for line in hex_values:
            if line.strip():
                code += f"#CONFIG {line}\n"
        
        return code

class BootloaderDialog(QDialog):
    def __init__(self, parent=None, chip="PIC16F877A", current_config=None):
        super().__init__(parent)
        self.setWindowTitle("Configure Bootloader")
        self.chip = chip
        self.config = current_config or {
            "basic": True,
            "lock_gpio": False,
            "backup": False,
            "error_led": False,
            "error_led_pin": "PORTA.0"
        }
        layout = QFormLayout()
        self.basic_check = QCheckBox("Enable Basic Bootloader")
        self.basic_check.setChecked(self.config["basic"])
        layout.addRow(self.basic_check)
        self.lock_gpio_check = QCheckBox("Lock GPIO Direction")
        self.lock_gpio_check.setChecked(self.config["lock_gpio"])
        layout.addRow(self.lock_gpio_check)
        self.backup_check = QCheckBox("Backup Old Program")
        self.backup_check.setChecked(self.config["backup"])
        layout.addRow(self.backup_check)
        self.error_led_check = QCheckBox("Enable Error LED")
        self.error_led_check.setChecked(self.config["error_led"])
        self.error_led_check.stateChanged.connect(self.toggle_error_led)
        layout.addRow(self.error_led_check)
        self.error_led_pin = QComboBox()
        self.error_led_pin.addItems(["PORTA.0", "PORTA.1", "PORTB.0", "PORTB.1"])
        self.error_led_pin.setCurrentText(self.config["error_led_pin"])
        self.error_led_pin.setEnabled(self.config["error_led"])
        layout.addRow("Error LED Pin:", self.error_led_pin)
        generate_button = QPushButton("Generate")
        generate_button.clicked.connect(self.accept)
        layout.addWidget(generate_button)
        self.setLayout(layout)

    def toggle_error_led(self, state):
        self.error_led_pin.setEnabled(state == Qt.Checked)

    def get_config(self):
        return {
            "basic": self.basic_check.isChecked(),
            "lock_gpio": self.lock_gpio_check.isChecked(),
            "backup": self.backup_check.isChecked(),
            "error_led": self.error_led_check.isChecked(),
            "error_led_pin": self.error_led_pin.currentText() if self.error_led_check.isChecked() else ""
        }

class GCBASICHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None, scheme=None):
        super().__init__(parent)
        self.scheme = scheme or ColorScheme()
        self.highlighting_rules = []
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(self.scheme.get_color("keyword"))
        keywords = [
            '#INCLUDE', 'DIR', 'OUT', 'IN', 'SET', 'IF', 'THEN', 'ELSE', 'ENDIF',
            'STEPCW', 'STEPCCW', '#CHIP', '#DEFINE', 'FOR', 'TO', 'NEXT', 'WHILE',
            'LOOP', 'DO', 'UNTIL', 'SELECT', 'CASE', 'END', 'SUB', 'DIM', 'AS',
            'BYTE', 'WORD', 'LONG', 'INTEGER', 'STRING', 'HSEROUT', 'HSERIN',
            'ModbusRTUwrite', 'ModbusRTUread', 'WAIT', 'GLCDCLS', 'GLCDPRINT',
            'CLS', 'PRINT', 'PWMON', 'PWMDUTY', 'SPIMODE', 'SPIWRITE', 'CANWRITE',
            'PIDCONTROL', 'EEPROMWRITE', 'EEPROMREAD', 'TONE', 'ONEWIREREAD',
            'RTCREAD', 'USBWRITE', 'ETHERNETINIT', 'DMASTART', 'TASKCREATE',
            'MQTTPUBLISH', 'HTTPINIT'
        ]
        for word in keywords:
            self.highlighting_rules.append((fr'\b{word}\b', keyword_format))
        comment_format = QTextCharFormat()
        comment_format.setForeground(self.scheme.get_color("comment"))
        self.highlighting_rules.append((r';[^\n]*', comment_format))
        self.highlighting_rules.append((r"'[^\n]*", comment_format))
        string_format = QTextCharFormat()
        string_format.setForeground(self.scheme.get_color("string"))
        self.highlighting_rules.append((r'"[^"]*"', string_format))

    def highlightBlock(self, text):
        for pattern, format in self.highlighting_rules:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                self.setFormat(match.start(), match.end() - match.start(), format)

class SnippetDialog(QDialog):
    def __init__(self, parent=None, chip="PIC16F877A", assigned_pins=None):
        super().__init__(parent)
        self.setWindowTitle("Insert Snippet")
        self.chip = chip
        self.assigned_pins = assigned_pins or {}
        self.local_assigned_pins = {}
        self.snippets_dir = os.path.expanduser("~/.SuperIDE/snippets")
        os.makedirs(self.snippets_dir, exist_ok=True)
        self.microcontroller_pins = self.get_microcontroller_pins()
        self.setup_ui()

    def get_microcontroller_pins(self):
        pin_configs = {
            "PIC16F877A": {
                "digital": [f"PORT{p}.{i}" for p in "ABCD" for i in range(8)],
                "adc_channels": [f"AN{i}" for i in range(8)],
                "pwm_channels": ["PORTC.1", "PORTC.2"],
                "uart1_tx": ["PORTC.6"],
                "uart1_rx": ["PORTC.7"],
                "i2c1_sda": ["PORTC.4"],
                "i2c1_scl": ["PORTC.3"],
                "spi1_mosi": ["PORTC.5"],
                "spi1_miso": ["PORTC.4"],
                "spi1_sck": ["PORTC.3"],
                "spi_cs": ["PORTB.0"],
                "lcd_data": [f"PORT{p}.{i}" for p in "BD" for i in range(8)],
                "lcd_control": [f"PORT{p}.{i}" for p in "BD" for i in range(8)],
                "glcd_data": [f"PORT{p}.{i}" for p in "BD" for i in range(8)],
                "glcd_control": [f"PORT{p}.{i}" for p in "BD" for i in range(8)],
                "can_tx": ["PORTC.6"],
                "can_rx": ["PORTC.7"],
                "stepper": [f"PORT{p}.{i}" for p in "BD" for i in range(8)],
                "interrupt": ["PORTB.0"],
                "tone": [f"PORT{p}.{i}" for p in "BD" for i in range(8)],
                "onewire": [f"PORT{p}.{i}" for p in "BD" for i in range(8)],
                "usb_dm": ["PORTC.0"],
                "usb_dp": ["PORTC.1"]
            },
            "ATMega328P": {
                "digital": [f"PORT{p}.{i}" for p in "BCD" for i in range(8)],
                "adc_channels": [f"ADC{i}" for i in range(6)],
                "pwm_channels": ["PORTB.1", "PORTB.2", "PORTD.3", "PORTD.5", "PORTD.6"],
                "uart1_tx": ["PORTD.1"],
                "uart1_rx": ["PORTD.0"],
                "i2c1_sda": ["PORTC.4"],
                "i2c1_scl": ["PORTC.5"],
                "spi1_mosi": ["PORTB.3"],
                "spi1_miso": ["PORTB.4"],
                "spi1_sck": ["PORTB.5"],
                "spi_cs": ["PORTB.2"],
                "lcd_data": [f"PORT{p}.{i}" for p in "BCD" for i in range(8)],
                "lcd_control": [f"PORT{p}.{i}" for p in "BCD" for i in range(8)],
                "glcd_data": [f"PORT{p}.{i}" for p in "BCD" for i in range(8)],
                "glcd_control": [f"PORT{p}.{i}" for p in "BCD" for i in range(8)],
                "can_tx": [],
                "can_rx": [],
                "stepper": [f"PORT{p}.{i}" for p in "BCD" for i in range(8)],
                "interrupt": ["PORTD.2", "PORTD.3"],
                "tone": [f"PORT{p}.{i}" for p in "BCD" for i in range(8)],
                "onewire": [f"PORT{p}.{i}" for p in "BCD" for i in range(8)],
                "usb_dm": [],
                "usb_dp": []
            }
        }
        return pin_configs.get(self.chip, pin_configs["PIC16F877A"])

    def setup_ui(self):
        self.layout = QFormLayout()
        self.snippet_type = QComboBox()
        self.snippet_type.addItems([
            "I2C", "ADC", "PWM", "UART", "SPI", "LCD", "GLCD", "CAN", "PID", "STEPPER",
            "MODBUSRTU", "MODBUSTCP", "EEPROM", "INTERRUPT", "TONE", "ONEWIRE", "RTC",
            "USB", "ETHERNET", "DMA", "RTOS", "MQTT", "HTTP"
        ])
        self.snippet_type.currentTextChanged.connect(self.update_fields)
        self.layout.addRow("Snippet Type:", self.snippet_type)
        self.show_pin_directions = QCheckBox("Show Pin Directions in Snippet")
        self.show_pin_directions.setChecked(False)
        self.layout.addRow(self.show_pin_directions)
        self.pin_frame = QWidget()
        self.pin_layout = QFormLayout(self.pin_frame)
        self.layout.addWidget(self.pin_frame)
        self.pin_inputs = {}
        self.reassign_buttons = {}
        self.address_input = None
        self.mode_input = None
        self.param_inputs = {}
        self.update_fields(self.snippet_type.currentText())
        insert_button = QPushButton("Insert")
        insert_button.clicked.connect(self.generate_snippet)
        self.layout.addWidget(insert_button)
        self.setLayout(self.layout)

    def get_pin_configs(self):
        return {
            "I2C": [("I2C_DATA_Pin", "i2c1_sda"), ("I2C_CLOCK_Pin", "i2c1_scl")],
            "ADC": [("Channel", "adc_channels")],
            "PWM": [("PWM_Pin", "pwm_channels")],
            "UART": [("TX_Pin", "uart1_tx"), ("RX_Pin", "uart1_rx")],
            "SPI": [("MOSI_Pin", "spi1_mosi"), ("MISO_Pin", "spi1_miso"), ("SCK_Pin", "spi1_sck"), ("CS_Pin", "spi_cs")],
            "LCD": [("D4_Pin", "lcd_data"), ("D5_Pin", "lcd_data"), ("D6_Pin", "lcd_data"), ("D7_Pin", "lcd_data"),
                    ("RS_Pin", "lcd_control"), ("EN_Pin", "lcd_control")],
            "GLCD": [("D0_Pin", "glcd_data"), ("D1_Pin", "glcd_data"), ("D2_Pin", "glcd_data"), ("D3_Pin", "glcd_data"),
                     ("D4_Pin", "glcd_data"), ("D5_Pin", "glcd_data"), ("D6_Pin", "glcd_data"), ("D7_Pin", "glcd_data"),
                     ("RS_Pin", "glcd_control"), ("EN_Pin", "glcd_control"), ("RW_Pin", "glcd_control"),
                     ("CS1_Pin", "glcd_control"), ("CS2_Pin", "glcd_control")],
            "CAN": [("TX_Pin", "can_tx"), ("RX_Pin", "can_rx")],
            "PID": [("Input_Pin", "adc_channels"), ("Output_Pin", "pwm_channels")],
            "STEPPER": [("IN1_Pin", "stepper"), ("IN2_Pin", "stepper"), ("IN3_Pin", "stepper"), ("IN4_Pin", "stepper")],
            "MODBUSRTU": [("TX_Pin", "uart1_tx"), ("RX_Pin", "uart1_rx")],
            "MODBUSTCP": [],
            "EEPROM": [],
            "INTERRUPT": [("Trigger_Pin", "interrupt")],
            "TONE": [("Buzzer_Pin", "tone")],
            "ONEWIRE": [("Data_Pin", "onewire")],
            "RTC": [("SCL_Pin", "i2c1_scl"), ("SDA_Pin", "i2c1_sda")],
            "USB": [("DM_Pin", "usb_dm"), ("DP_Pin", "usb_dp")],
            "ETHERNET": [],
            "DMA": [("Peripheral_Pin", "adc_channels")],
            "RTOS": [],
            "MQTT": [],
            "HTTP": []
        }

    def update_pin_fields(self):
        while self.pin_layout.count():
            child = self.pin_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
        self.pin_inputs.clear()
        self.reassign_buttons.clear()
        self.local_assigned_pins.clear()
        pin_configs = self.get_pin_configs().get(self.snippet_type.currentText(), [])
        for label, pin_type in pin_configs:
            row_layout = QHBoxLayout()
            combo = QComboBox()
            available_pins = ["None"] + [
                p for p in self.microcontroller_pins.get(pin_type, [])
                if p not in self.assigned_pins.values() or p == self.assigned_pins.get(label, "None")
            ]
            combo.addItems(available_pins)
            if len(self.microcontroller_pins.get(pin_type, [])) == 1 and available_pins != ["None"]:
                combo.setEnabled(False)
                if available_pins[1] != "None":
                    self.local_assigned_pins[label] = available_pins[1]
                    combo.setCurrentText(available_pins[1])
            combo.currentTextChanged.connect(lambda text, l=label: self.update_pin_selections(l, text))
            row_layout.addWidget(combo)
            self.pin_inputs[label] = combo
            if label not in self.local_assigned_pins:
                self.local_assigned_pins[label] = combo.currentText()
            if len(self.microcontroller_pins.get(pin_type, [])) == 1:
                reassign_btn = QPushButton("Reassign")
                reassign_btn.clicked.connect(lambda _, l=label, t=pin_type: self.reassign_pin(l, t))
                row_layout.addWidget(reassign_btn)
                self.reassign_buttons[label] = reassign_btn
            self.pin_layout.addRow(f"{label.replace('_Pin', '')}:", row_layout)

    def reassign_pin(self, label, pin_type):
        current_pin = self.pin_inputs[label].currentText()
        available_pins = self.microcontroller_pins.get(pin_type, [])
        if not available_pins:
            QMessageBox.warning(self, "No Pins", f"No pins available for {pin_type}.")
            return
        reply = QMessageBox.question(
            self, "Confirm Reassignment",
            f"Reassign {label} from {current_pin}?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self.pin_inputs[label].setEnabled(True)
            self.reassign_buttons[label].setEnabled(False)
            self.update_pin_selections(label, current_pin)

    def update_pin_selections(self, changed_label, selected_pin):
        if selected_pin == "None":
            self.local_assigned_pins[changed_label] = selected_pin
        else:
            current_owner = next((k for k, v in self.assigned_pins.items() if v == selected_pin), None)
            if current_owner and current_owner != changed_label:
                reply = QMessageBox.question(
                    self, "Pin Conflict",
                    f"Pin {selected_pin} is assigned to {current_owner}. Reassign?",
                    QMessageBox.Yes | QMessageBox.No
                )
                if reply == QMessageBox.No:
                    self.pin_inputs[changed_label].setCurrentText("None")
                    return
            self.local_assigned_pins[changed_label] = selected_pin
        for label, combo in self.pin_inputs.items():
            current = combo.currentText()
            combo.blockSignals(True)
            combo.clear()
            pin_type = next(pt for l, pt in self.get_pin_configs().get(self.snippet_type.currentText(), []) if l == label)
            available = ["None"] + [
                p for p in self.microcontroller_pins.get(pin_type, [])
                if p not in self.local_assigned_pins.values() or p == current
                if p not in self.assigned_pins.values() or p == self.assigned_pins.get(label, "None") or p == current
            ]
            combo.addItems(available)
            combo.setCurrentText(current)
            if len(self.microcontroller_pins.get(pin_type, [])) == 1 and available != ["None"]:
                combo.setEnabled(False)
            combo.blockSignals(False)

    def update_fields(self, snippet_type):
        for label, combo in self.pin_inputs.items():
            combo.setVisible(False)
        if self.address_input:
            self.address_input.setVisible(False)
            self.address_input.deleteLater()
            self.address_input = None
        if self.mode_input:
            self.mode_input.setVisible(False)
            self.mode_input.deleteLater()
            self.mode_input = None
        for label, input_field in self.param_inputs.items():
            input_field.setVisible(False)
            input_field.deleteLater()
        self.param_inputs.clear()
        self.update_pin_fields()
        if snippet_type in ["I2C", "SPI", "MODBUSRTU", "RTC"]:
            self.address_input = QLineEdit("0xA0" if snippet_type in ["I2C", "RTC"] else "1")
            self.layout.addRow("Address:", self.address_input)
        elif snippet_type in ["MODBUSTCP", "MQTT", "HTTP"]:
            self.address_input = QLineEdit("192.168.1.100")
            self.layout.addRow("IP Address:", self.address_input)
        if snippet_type in ["I2C", "SPI", "MODBUSRTU"]:
            self.mode_input = QComboBox()
            self.mode_input.addItems(["Master", "Slave"])
            self.layout.addRow("Mode:", self.mode_input)
        if snippet_type == "TONE":
            self.param_inputs["Frequency"] = QLineEdit("1000")
            self.param_inputs["Duration"] = QLineEdit("500")
            self.layout.addRow("Frequency (Hz):", self.param_inputs["Frequency"])
            self.layout.addRow("Duration (ms):", self.param_inputs["Duration"])
        elif snippet_type == "INTERRUPT":
            self.param_inputs["Type"] = QComboBox()
            self.param_inputs["Type"].addItems(["Timer0", "INT0", "ADC"])
            self.layout.addRow("Interrupt Type:", self.param_inputs["Type"])
        elif snippet_type == "RTOS":
            self.param_inputs["TaskName"] = QLineEdit("Task1")
            self.param_inputs["Priority"] = QLineEdit("1")
            self.layout.addRow("Task Name:", self.param_inputs["TaskName"])
            self.layout.addRow("Priority:", self.param_inputs["Priority"])
        elif snippet_type == "MQTT":
            self.param_inputs["Topic"] = QLineEdit("sensor/data")
            self.layout.addRow("Topic:", self.param_inputs["Topic"])
        elif snippet_type == "PID":
            self.param_inputs["Kp"] = QLineEdit("2.0")
            self.param_inputs["Ki"] = QLineEdit("1.0")
            self.param_inputs["Kd"] = QLineEdit("1.0")
            self.param_inputs["Setpoint"] = QLineEdit("512")
            self.param_inputs["ZieglerNichols"] = QCheckBox("Enable Ziegler-Nichols Autotune")
            self.layout.addRow("Kp:", self.param_inputs["Kp"])
            self.layout.addRow("Ki:", self.param_inputs["Ki"])
            self.layout.addRow("Kd:", self.param_inputs["Kd"])
            self.layout.addRow("Setpoint:", self.param_inputs["Setpoint"])
            self.layout.addRow(self.param_inputs["ZieglerNichols"])
        elif snippet_type == "GLCD":
            self.param_inputs["GLCD_TYPE"] = QComboBox()
            self.param_inputs["GLCD_TYPE"].addItems(["KS0108", "ST7920PARALLEL", "ST7920SPI"])
            self.layout.addRow("GLCD Type:", self.param_inputs["GLCD_TYPE"])
        elif snippet_type == "ADC":
            self.param_inputs["Bit_Resolution"] = QComboBox()
            self.param_inputs["Bit_Resolution"].addItems(["10", "12", "16"])
            self.layout.addRow("Bit Resolution:", self.param_inputs["Bit_Resolution"])
        elif snippet_type == "UART":
            self.param_inputs["Baud_Rate"] = QComboBox()
            self.param_inputs["Baud_Rate"].addItems([
                "300", "600", "1200", "2400", "4800", "9600",
                "14400", "19200", "38400", "57600", "115200"
            ])
            self.param_inputs["Baud_Rate"].setCurrentText("9600")
            self.layout.addRow("Baud Rate:", self.param_inputs["Baud_Rate"])

    def validate_ip(self, ip):
        pattern = re.compile(r"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$")
        return pattern.match(ip) is not None

    def validate_float(self, value):
        try:
            float(value)
            return True
        except ValueError:
            return False

    def validate_pin(self, pin, pin_type):
        return pin == "None" or pin in self.microcontroller_pins.get(pin_type, [])

    def write_snippet_file(self, snippet_type, pin_directions):
        snippet_file = os.path.join(self.snippets_dir, f"{snippet_type.lower()}.gcb")
        with open(snippet_file, "w") as f:
            f.write("; Auto-generated snippet configuration\n")
            if pin_directions:
                f.write("\n".join(pin_directions) + "\n")
            f.write(f"; Implementation details for {snippet_type}\n")

    def generate_snippet(self):
        snippet_type = self.snippet_type.currentText()
        show_directions = self.show_pin_directions.isChecked()
        pins = {label: combo.currentText() for label, combo in self.pin_inputs.items()}
        for label, pin in pins.items():
            pin_type = next(pt for l, pt in self.get_pin_configs().get(snippet_type, []) if l == label)
            if not self.validate_pin(pin, pin_type):
                QMessageBox.critical(self, "Error", f"Invalid pin {pin} for {label}.")
                return
        address = self.address_input.text() if self.address_input else "1"
        if snippet_type in ["MODBUSTCP", "MQTT", "HTTP"] and not self.validate_ip(address):
            QMessageBox.critical(self, "Error", "Invalid IP address format.")
            return
        mode = self.mode_input.currentText() if self.mode_input else "Master"
        mode_gcb = "Master" if mode == "Master" else "Slave"
        params = {}
        for k, v in self.param_inputs.items():
            if isinstance(v, QLineEdit):
                params[k] = v.text()
            elif isinstance(v, QComboBox):
                params[k] = v.currentText()
            elif isinstance(v, QCheckBox):
                params[k] = v.isChecked()
        if snippet_type == "PID":
            for param in ["Kp", "Ki", "Kd", "Setpoint"]:
                if not self.validate_float(params.get(param, "0")):
                    QMessageBox.critical(self, "Error", f"Invalid {param} value: must be a number.")
                    return
        pin_directions = []
        output_pins = []
        if snippet_type in ["PWM", "LCD", "GLCD", "STEPPER", "TONE"]:
            for label, pin in pins.items():
                if pin != "None":
                    pin_directions.append(f"DIR {pin} OUT")
                    output_pins.append(pin)
        if not show_directions and pin_directions:
            self.write_snippet_file(snippet_type, pin_directions)
            pin_directions = []
        snippets = {
            "I2C": """
#INCLUDE "i2c.gcb"
{pin_directions}
I2CStart
I2CWrite {address}, 0x55
I2CRead {address}, Data
I2CStop
            """,
            "ADC": """
#INCLUDE "adc.gcb"
DIM ADC_Value AS LONG
ADC_Value = ReadAD{Bit_Resolution}({Channel})
            """,
            "PWM": """
#INCLUDE "pwm.gcb"
{pin_directions}
#DEFINE PWM_PIN {PWM_Pin}
PWMOn
PWMDuty PWM_PIN, 128
            """,
            "UART": """
#INCLUDE "usart.gcb"
{pin_directions}
#DEFINE USART_TX {TX_Pin}
#DEFINE USART_RX {RX_Pin}
#DEFINE USART_BAUD {Baud_Rate}
HSerPrint "Hello"
            """,
            "SPI": """
#INCLUDE "spi.gcb"
{pin_directions}
SPIMode {mode}, 0
SPIWrite 0x55
            """,
            "LCD": """
#INCLUDE "lcd.gcb"
{pin_directions}
#DEFINE LCD_IO 4
#DEFINE LCD_RS {RS_Pin}
#DEFINE LCD_Enable {EN_Pin}
#DEFINE LCD_Data4 {D4_Pin}
#DEFINE LCD_Data5 {D5_Pin}
#DEFINE LCD_Data6 {D6_Pin}
#DEFINE LCD_Data7 {D7_Pin}
CLS
PRINT "Hello"
            """,
            "GLCD": """
#INCLUDE "glcd.gcb"
{pin_directions}
#DEFINE GLCD_TYPE {GLCD_TYPE}
#DEFINE GLCD_RS {RS_Pin}
#DEFINE GLCD_RW {RW_Pin}
#DEFINE GLCD_Enable {EN_Pin}
#DEFINE GLCD_CS1 {CS1_Pin}
#DEFINE GLCD_CS2 {CS2_Pin}
#DEFINE GLCD_Data0 {D0_Pin}
#DEFINE GLCD_Data1 {D1_Pin}
#DEFINE GLCD_Data2 {D2_Pin}
#DEFINE GLCD_Data3 {D3_Pin}
#DEFINE GLCD_Data4 {D4_Pin}
#DEFINE GLCD_Data5 {D4_Pin}
#DEFINE GLCD_Data6 {D6_Pin}
#DEFINE GLCD_Data7 {D7_Pin}
GLCDCLS
GLCDPrint 0, 0, "Test"
            """,
            "CAN": """
#INCLUDE "can.gcb"
{pin_directions}
CANWrite 0x123, 8, Data
            """,
            "PID": """
#INCLUDE "pid.gasas"
{pin_directions}
DIM Setpoint AS WORD
Setpoint = {Setpoint}
{ZieglerNichols}
PIDControl {Input_Pin}, {Output_Pin}, Setpoint, {Kp}, {Ki}, {Kd}
            """,
            "STEPPER": """
#INCLUDE "stepper.gcb"
{pin_directions}
#DEFINE STEPPER_IN1 {IN1_Pin}
#DEFINE STEPPER_IN2 {IN2_Pin}
#DEFINE STEPPER_IN3 {IN3_Pin}
#DEFINE STEPPER_IN4 {IN4_Pin}
StepCW STEPPER_IN1, STEPPER_IN2, STEPPER_IN3, STEPPER_IN4, 100, 10
StepCCW STEPPER_IN1, STEPPER_IN2, STEPPER_IN3, STEPPER_IN4, 100, 10
            """,
            "MODBUSRTU": """
#INCLUDE "modbusrtu.gcb"
{pin_directions}
#DEFINE MODBUS_TX {TX_Pin}
#DEFINE MODBUS_RX {RX_Pin}
ModBusRTUWrite {address}, 100
ModBusRTURead {address}, Value
            """,
            "MODBUSTCP": """
#INCLUDE "modbustcp.gcb"
ModBusTCPWrite "{address}", 100
ModBusTCPRead "{address}", Value
            """,
            "EEPROM": """
#INCLUDE "eeprom.gcb"
EEPROMWrite 0, 0x55
EEPROMRead 0, Data
            """,
            "INTERRUPT": """
#INCLUDE "interrupts.gcb"
{pin_directions}
On Interrupt {Type} Call ISR
SUB ISR
    Toggle PORTC.0
END SUB
            """,
            "TONE": """
#INCLUDE "tone.gcb"
{pin_directions}
#DEFINE BUZZER_PIN {Buzzer_Pin}
Tone BUZZER_PIN, {Frequency}, {Duration}
            """,
            "ONEWIRE": """
#INCLUDE "onewire.gcb"
OneWireRead {Data_Pin}, Data
            """,
            "RTC": """
#INCLUDE "rtc.gcb"
{pin_directions}
RTCRead {address}, 0x00, Seconds
            """,
            "USB": """
#INCLUDE "usb.gcb"
{pin_directions}
USBWrite "Hello via USB"
            """,
            "ETHERNET": """
#INCLUDE "ethernet.gcb"
EthernetInit "{address}"
            """,
            "DMA": """
#INCLUDE "dma.gcb"
DMAStart {Peripheral_Pin}, Buffer, 100
            """,
            "RTOS": """
#INCLUDE "freertos.gcb"
TaskCreate {TaskName}, {Priority}
SUB {TaskName}
    DO
        Toggle PORTC.13
        Wait 1 s
    LOOP
END SUB
            """,
            "MQTT": """
#INCLUDE "mqtt.gcb"
MQTTPublish "{address}", "{Topic}", "Hello"
            """,
            "HTTP": """
#INCLUDE "http.gcb"
HTTPInit "{address}"
            """
        }
        try:
            if snippet_type == "PID":
                ziegler_nichols = "#DEFINE PID_AUTOTUNE_ZIEGLER_NICHOLS" if params.get("ZieglerNichols", False) else ""
                snippet = snippets[snippet_type].format(
                    pin_directions="\n".join(pin_directions) + "\n" if pin_directions else "",
                    address=address,
                    mode=mode_gcb,
                    Kp=params.get("Kp", "2.0"),
                    Ki=params.get("Ki", "1.0"),
                    Kd=params.get("Kd", "1.0"),
                    Setpoint=params.get("Setpoint", "512"),
                    ZieglerNichols=ziegler_nichols,
                    **pins,
                    **params
                ).strip()
            else:
                snippet = snippets[snippet_type].format(
                    pin_directions="\n".join(pin_directions) + "\n" if pin_directions else "",
                    address=address,
                    mode=mode_gcb,
                    **pins,
                    **params
                ).strip()
            for label, pin in pins.items():
                if pin != "None":
                    self.assigned_pins[label] = pin
            self.snippet = snippet
            self.accept()
        except KeyError as e:
            QMessageBox.critical(self, "Error", f"Missing or invalid parameter: {str(e)}")

    def get_snippet(self):
        return getattr(self, 'snippet', '')

class SuperIDE(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SuperIDE for GCBASIC")
        self.setGeometry(100, 100, 800, 600)
        self.current_file = None
        self.color_scheme = ColorScheme()
        self.font = QFont("Courier New", 10)
        self.tools = {"xc8": "", "avr-gcc": ""}
        self.microcontroller = "PIC16F877A"
        self.assigned_pins = {}
        self.bootloader_config = {
            "basic": True,
            "lock_gpio": False,
            "backup": False,
            "error_led": False,
            "error_led_pin": "PORTA.0"
        }
        self.match_case = False
        self.last_search = ""
        self.init_ui()
        self.load_settings()

    def init_ui(self):
        self.editor = QPlainTextEdit()
        self.editor.setFont(self.font)
        self.highlighter = GCBASICHighlighter(self.editor.document(), self.color_scheme)
        self.editor.blockCountChanged.connect(self.update_line_numbers)
        self.line_numbers = QTextEdit()
        self.line_numbers.setFont(self.font)
        self.line_numbers.setReadOnly(True)
        self.line_numbers.setFixedWidth(50)
        layout = QHBoxLayout()
        layout.addWidget(self.line_numbers)
        layout.addWidget(self.editor)
        central_widget = QWidget()
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)
        self.create_menu()
        os.makedirs(os.path.expanduser("~/.SuperIDE"), exist_ok=True)
        self.apply_color_scheme()

    def create_menu(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu("File")
        for name, shortcut, func in [
            ("New\tCtrl+N", "Ctrl+N", self.new_file),
            ("Open\tCtrl+O", "Ctrl+O", self.open_file),
            ("Save\tCtrl+S", "Ctrl+S", self.save_file),
            ("Save As...\tCtrl+Shift+S", "Ctrl+Shift+S", self.save_file_as),
            ("Exit\tCtrl+Q", "Ctrl+Q", self.exit_application)
        ]:
            action = QAction(name, self)
            action.setShortcut(shortcut)
            action.triggered.connect(func)
            file_menu.addAction(action)

        edit_menu = menubar.addMenu("Edit")
        for name, shortcut, func in [
            ("Undo\tCtrl+Z", "Ctrl+Z", self.undo),
            ("Redo\tCtrl+Y", "Ctrl+Y", self.redo),
            ("Cut\tCtrl+X", "Ctrl+X", self.cut),
            ("Copy\tCtrl+C", "Ctrl+C", self.copy),
            ("Paste\tCtrl+V", "Ctrl+V", self.paste),
            ("Find...\tCtrl+F", "Ctrl+F", self.find),
            ("Find Next\tF3", "F3", self.find_next),
            ("Replace...\tCtrl+H", "Ctrl+H", self.replace),
            ("Move Line Up\tCtrl+Shift+Up", "Ctrl+Shift+Up", self.move_line_up),
            ("Move Line Down\tCtrl+Shift+Down", "Ctrl+Shift+Down", self.move_line_down),
            ("Select All\tCtrl+A", "Ctrl+A", self.select_all),
            ("Toggle Match Case\tCtrl+M", "Ctrl+M", self.toggle_match_case)
        ]:
            action = QAction(name, self)
            action.setShortcut(shortcut)
            action.triggered.connect(func)
            edit_menu.addAction(action)

        build_menu = menubar.addMenu("Build")
        build_action = QAction("Build\tCtrl+B", self)
        build_action.setShortcut("Ctrl+B")
        build_action.triggered.connect(self.build)
        build_menu.addAction(build_action)
        bootloader_action = QAction("Generate Bootloader\tCtrl+Shift+B", self)
        bootloader_action.setShortcut("Ctrl+Shift+B")
        bootloader_action.triggered.connect(self.generate_bootloader)
        build_menu.addAction(bootloader_action)
        tools_menu = menubar.addMenu("Tools")
        configure_tools = QAction("Configure Tools\tCtrl+T", self)
        configure_tools.setShortcut("Ctrl+T")
        configure_tools.triggered.connect(self.configure_tools)
        tools_menu.addAction(configure_tools)
        device_menu = menubar.addMenu("Device")
        select_device = QAction("Select Microcontroller\tCtrl+D", self)
        select_device.setShortcut("Ctrl+D")
        select_device.triggered.connect(self.select_microcontroller)
        device_menu.addAction(select_device)
        config_chip = QAction("Configure Chip\tCtrl+Shift+C", self)
        config_chip.setShortcut("Ctrl+Shift+C")
        config_chip.triggered.connect(self.configure_chip)
        device_menu.addAction(config_chip)
        insert_menu = menubar.addMenu("Insert")
        snippets = [
            ("I2C", "Ctrl+Shift+I"),
            ("ADC", "Ctrl+Shift+A"),
            ("PWM", "Ctrl+Shift+P"),
            ("UART", "Ctrl+Shift+U"),
            ("SPI", "Ctrl+Shift+S"),
            ("LCD", "Ctrl+Shift+L"),
            ("GLCD", "Ctrl+Shift+G"),
            ("CAN", "Ctrl+Shift+C"),
            ("PID", "Ctrl+Shift+D"),
            ("STEPPER", "Ctrl+Shift+T"),
            ("MODBUSRTU", "Ctrl+Shift+M"),
            ("MODBUSTCP", "Ctrl+Shift+N"),
            ("EEPROM", "Ctrl+Shift+E"),
            ("INTERRUPT", "Ctrl+Shift+R"),
            ("TONE", "Ctrl+Shift+O"),
            ("ONEWIRE", "Ctrl+Shift+W"),
            ("RTC", "Ctrl+Shift+Q"),
            ("USB", "Ctrl+Shift+V"),
            ("ETHERNET", "Ctrl+Shift+Y"),
            ("DMA", "Ctrl+Shift+Z"),
            ("RTOS", "Ctrl+Shift+X"),
            ("MQTT", "Ctrl+Shift+K"),
            ("HTTP", "Ctrl+Shift+J")
        ]
        for snippet, shortcut in snippets:
            action = QAction(f"Insert {snippet}\t{shortcut}", self)
            action.setShortcut(shortcut)
            action.triggered.connect(lambda checked, s=snippet: self.insert_snippet(s))
            insert_menu.addAction(action)
        view_menu = menubar.addMenu("View")
        color_scheme_menu = view_menu.addMenu("Color Scheme")
        color_shortcuts = [
            ("Light", "Ctrl+Alt+L"),
            ("Dark", "Ctrl+Alt+D"),
            ("Solarized Light", "Ctrl+Alt+S"),
            ("Solarized Dark", "Ctrl+Alt+A"),
            ("Monokai", "Ctrl+Alt+M"),
            ("Dracula", "Ctrl+Alt+R"),
            ("One Dark", "Ctrl+Alt+O"),
            ("Nord", "Ctrl+Alt+N"),
            ("Gruvbox", "Ctrl+Alt+G"),
            ("Tomorrow Light", "Ctrl+Alt+T")
        ]
        for scheme_name, shortcut in color_shortcuts:
            action = QAction(f"{scheme_name}\t{shortcut}", self)
            action.setShortcut(shortcut)
            action.triggered.connect(lambda checked, name=scheme_name: self.set_color_scheme(name))
            color_scheme_menu.addAction(action)
        custom_scheme_action = QAction("Customize...\tCtrl+Alt+C", self)
        custom_scheme_action.setShortcut("Ctrl+Alt+C")
        custom_scheme_action.triggered.connect(self.customize_color_scheme)
        color_scheme_menu.addAction(custom_scheme_action)
        font_menu = view_menu.addMenu("Font")
        select_font_action = QAction("Select Font...\tCtrl+Alt+F", self)
        select_font_action.setShortcut("Ctrl+Alt+F")
        select_font_action.triggered.connect(self.select_font)
        font_menu.addAction(select_font_action)
        help_menu = menubar.addMenu("Help")
        about_action = QAction("About\tCtrl+H", self)
        about_action.setShortcut("Ctrl+H")
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def undo(self):
        self.editor.undo()

    def redo(self):
        self.editor.redo()

    def cut(self):
        self.editor.cut()

    def copy(self):
        self.editor.copy()

    def paste(self):
        self.editor.paste()

    def select_all(self):
        self.editor.selectAll()

    def find(self):
        search_text, ok = QInputDialog.getText(self, "Find", "Enter text to find:")
        if ok and search_text:
            self.last_search = search_text
            cursor = self.editor.document().find(search_text, 0, Qt.MatchCaseSensitive if self.match_case else 0)
            if not cursor.isNull():
                self.editor.setTextCursor(cursor)
            else:
                QMessageBox.information(self, "Find", "Text not found.")

    def find_next(self):
        if not self.last_search:
            self.find()
            return
        cursor = self.editor.textCursor()
        next_cursor = self.editor.document().find(
            self.last_search, cursor, Qt.MatchCaseSensitive if self.match_case else 0
        )
        if not next_cursor.isNull():
            self.editor.setTextCursor(next_cursor)
        else:
            QMessageBox.information(self, "Find", "No more occurrences found.")

    def replace(self):
        search_text, ok = QInputDialog.getText(self, "Replace", "Enter text to find:")
        if not ok or not search_text:
            return
        replace_text, ok = QInputDialog.getText(self, "Replace", "Enter replacement text:")
        if not ok:
            return
        cursor = self.editor.document().find(search_text, 0, Qt.MatchCaseSensitive if self.match_case else 0)
        if not cursor.isNull():
            self.editor.setTextCursor(cursor)
            cursor.insertText(replace_text)
            QMessageBox.information(self, "Replace", "Text replaced.")
        else:
            QMessageBox.information(self, "Replace", "Text not found.")

    def move_line_up(self):
        cursor = self.editor.textCursor()
        cursor.beginEditBlock()
        block = cursor.block()
        if block.previous().isValid():
            text = block.text()
            cursor.select(QTextCursor.BlockUnderCursor)
            cursor.removeSelectedText()
            cursor.movePosition(QTextCursor.Up)
            cursor.insertText(text + "\n")
            cursor.movePosition(QTextCursor.Up)
            self.editor.setTextCursor(cursor)
        cursor.endEditBlock()

    def move_line_down(self):
        cursor = self.editor.textCursor()
        cursor.beginEditBlock()
        block = cursor.block()
        if block.next().isValid():
            text = block.text()
            cursor.select(QTextCursor.BlockUnderCursor)
            cursor.removeSelectedText()
            cursor.movePosition(QTextCursor.Down)
            cursor.insertText(text + "\n")
            self.editor.setTextCursor(cursor)
        cursor.endEditBlock()

    def toggle_match_case(self):
        self.match_case = not self.match_case
        QMessageBox.information(self, "Match Case", f"Match case {'enabled' if self.match_case else 'disabled'}.")

    def show_about(self):
        QMessageBox.information(
            self,
            "About SuperIDE",
            "SuperIDE for GCBASIC\n\n"
            "Developed by: Samukelo Shezi\n"
            "Location: Polokwane\n"
            "Email: sfshezi2@gmail.com"
        )

    def insert_snippet(self, snippet_type):
        dialog = SnippetDialog(self, self.microcontroller, self.assigned_pins)
        dialog.snippet_type.setCurrentText(snippet_type)
        dialog.update_fields(snippet_type)
        if dialog.exec_():
            self.editor.insertPlainText(dialog.get_snippet())
            self.assigned_pins.update({
                k: v for k, v in dialog.assigned_pins.items()
                if v != "None" and k in dialog.pin_inputs
            })

    def configure_chip(self):
        dialog = ChipConfigDialog(self, self.microcontroller)
        if dialog.exec_():
            self.editor.insertPlainText(dialog.get_config_code())

    def set_color_scheme(self, scheme_name):
        self.color_scheme = ColorScheme(scheme_name)
        self.apply_color_scheme()
        self.save_settings()

    def customize_color_scheme(self):
        dialog = ColorSchemeDialog(self, self.color_scheme)
        if dialog.exec_():
            self.color_scheme = dialog.get_scheme()
            self.apply_color_scheme()
            self.save_settings()

    def select_font(self):
        dialog = FontDialog(self, self.font, self.font.pointSize())
        if dialog.exec_():
            self.font = dialog.get_font()
            self.font.setPointSize(dialog.get_size())
            self.editor.setFont(self.font)
            self.line_numbers.setFont(self.font)
            self.save_settings()

    def apply_color_scheme(self):
        self.editor.setStyleSheet(
            f"background-color: {self.color_scheme.colors['background']}; "
            f"color: {self.color_scheme.colors['foreground']};"
        )
        self.line_numbers.setStyleSheet(
            f"background-color: {self.color_scheme.colors['line_numbers_bg']}; "
            f"color: {self.color_scheme.colors['line_numbers_fg']};"
        )
        self.highlighter = GCBASICHighlighter(self.editor.document(), self.color_scheme)
        self.editor.update()

    def update_line_numbers(self):
        lines = self.editor.blockCount()
        line_numbers = "\n".join(str(i) for i in range(1, lines + 1))
        self.line_numbers.setText(line_numbers)

    def new_file(self):
        self.editor.clear()
        self.current_file = None
        self.assigned_pins.clear()

    def open_file(self):
        file_name, _ = QFileDialog.getOpenFileName(
            self, "Open File", "", "GCBASIC Files (*.gcb);;All Files (*.*)"
        )
        if file_name:
            try:
                with open(file_name, 'r') as file:
                    self.editor.setPlainText(file.read())
                self.current_file = file_name
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to open file: {str(e)}")

    def save_file(self):
        if not self.current_file:
            self.save_file_as()
            if not self.current_file:
                return
        else:
            try:
                with open(self.current_file, 'w') as file:
                    file.write(self.editor.toPlainText())
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save file: {str(e)}")

    def save_file_as(self):
        file_name, _ = QFileDialog.getSaveFileName(
            self, "Save File As", "", "GCBASIC Files (*.gcb);;All Files (*.*)"
        )
        if file_name:
            self.current_file = file_name
            self.save_file()

    def exit_application(self):
        self.save_settings()
        QApplication.quit()

    def select_microcontroller(self):
        dialog = MicrocontrollerDialog(self, self.microcontroller)
        if dialog.exec_():
            self.microcontroller = dialog.get_selected_device()
            self.assigned_pins.clear()
            self.save_settings()

    def configure_tools(self):
        dialog = ToolConfigDialog(self, self.tools)
        if dialog.exec_():
            self.tools = dialog.get_tools()
            self.save_settings()

    def generate_bootloader(self):
        dialog = BootloaderDialog(self, self.microcontroller, self.bootloader_config)
        if dialog.exec_():
            self.bootloader_config = dialog.get_config()
            self.save_settings()
            bootloader_code = self.create_bootloader_code()
            self.editor.insertPlainText(bootloader_code)

    def create_bootloader_code(self):
        code = f"; Bootloader for {self.microcontroller}\n"
        if self.bootloader_config["basic"]:
            code += "#INCLUDE <bootloader.gcb>\n"
            code += "BootloaderInit\n"
        if self.bootloader_config["lock_gpio"]:
            code += "; Lock GPIO directions\n"
            code += "DIR PORTA OUT\nDIR PORTB OUT\n"
        if self.bootloader_config["backup"]:
            code += "; Backup program to EEPROM\n"
            code += "BackupProgram\n"
        if self.bootloader_config["error_led"]:
            code += f"; Error LED on {self.bootloader_config['error_led_pin']}\n"
            code += f"DIR {self.bootloader_config['error_led_pin']} OUT\n"
            code += f"SET {self.bootloader_config['error_led_pin']} OFF\n"
        return code

    def build(self):
        if not self.current_file:
            self.save_file_as()
            if not self.current_file:
                return
        compiler = ""
        if self.microcontroller.startswith("PIC"):
            compiler = os.path.join(self.tools["xc8"], "bin", "xc8-cc")
        elif self.microcontroller.startswith("ATMega") or self.microcontroller.startswith("ATtiny"):
            compiler = os.path.join(self.tools["avr-gcc"], "bin", "avr-gcc")
        if not compiler or not os.path.isfile(compiler):
            QMessageBox.critical(self, "Error", "Compiler not configured or not found.")
            return
        output_file = os.path.splitext(self.current_file)[0] + ".hex"
        cmd = [compiler, "-o", output_file, self.current_file]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode == 0:
                QMessageBox.information(self, "Success", "Build completed successfully.")
            else:
                QMessageBox.critical(self, "Build Error", result.stderr)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Build failed: {str(e)}")

    def load_settings(self):
        settings_file = os.path.expanduser("~/.SuperIDE/settings.json")
        if os.path.exists(settings_file):
            try:
                with open(settings_file, 'r') as file:
                    settings = json.load(file)
                self.tools = settings.get("tools", self.tools)
                self.microcontroller = settings.get("microcontroller", self.microcontroller)
                self.bootloader_config = settings.get("bootloader_config", self.bootloader_config)
                scheme_name = settings.get("color_scheme", "Light")
                custom_colors = settings.get("custom_colors", None)
                self.color_scheme = ColorScheme(scheme_name, custom_colors)
                font_settings = settings.get("font", {"family": "Courier New", "size": 10})
                self.font = QFont(font_settings["family"], font_settings["size"])
                self.match_case = settings.get("match_case", False)
                self.apply_color_scheme()
                self.editor.setFont(self.font)
                self.line_numbers.setFont(self.font)
            except Exception as e:
                QMessageBox.warning(self, "Warning", f"Failed to load settings: {str(e)}")

    def save_settings(self):
        settings = {
            "tools": self.tools,
            "microcontroller": self.microcontroller,
            "bootloader_config": self.bootloader_config,
            "color_scheme": self.color_scheme.name,
            "custom_colors": self.color_scheme.colors if self.color_scheme.name == "Custom" else None,
            "font": {"family": self.font.family(), "size": self.font.pointSize()},
            "match_case": self.match_case
        }
        settings_file = os.path.expanduser("~/.SuperIDE/settings.json")
        try:
            with open(settings_file, 'w') as file:
                json.dump(settings, file, indent=4)
        except Exception as e:
            QMessageBox.warning(self, "Warning", f"Failed to save settings: {str(e)}")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ide = SuperIDE()
    ide.show()
    sys.exit(app.exec_())

